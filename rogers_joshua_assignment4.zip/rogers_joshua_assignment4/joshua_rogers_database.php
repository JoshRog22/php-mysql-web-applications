<?php
/*
Author: Joshua Rogers
Course: CSCI 4000-W01
Date: 07/11/2026
Assignment 4 - Question 2
File: joshua_rogers_database.php

Purpose:
This file uses PDO to connect to the
joshua_rogers_student_db MySQL database.
If the connection fails, the database error page is displayed.
*/


// Stores the database connection information
$dsn = 'mysql:host=localhost;dbname=joshua_rogers_student_db';
$username = 'joshuarogers1';
$password = 'joshuaisgreat';


try {
    // Creates a PDO object and connects to the MySQL database
    $db = new PDO($dsn, $username, $password);

    // Causes PDO to report database problems as exceptions
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e) {
    // Stores the database error message
    $error_message = $e->getMessage();

    // Displays the database error page
    include('joshua_rogers_database_error.php');

    // Stops the remaining PHP code from running
    exit();
}
?>