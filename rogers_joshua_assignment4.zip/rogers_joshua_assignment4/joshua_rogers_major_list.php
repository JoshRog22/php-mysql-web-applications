<?php
/*
Author: Joshua Rogers
Course: CSCI 4000-W01
Date: 07/11/2026
Assignment 4 - Question 5 Extra Credit
File: joshua_rogers_major_list.php

Purpose:
This page connects to the database, retrieves all records
from the major table, displays the major list, and provides
forms for adding and deleting majors.
*/


// Connects to the Assignment 4 database using PDO
require_once('joshua_rogers_database.php');


// Retrieves all major records from the major table
$query = 'SELECT majorID, majorName
          FROM major
          ORDER BY majorID';


// Prepares and executes the SELECT query
$statement = $db->prepare($query);
$statement->execute();


// Stores all major records in the $majors array
$majors = $statement->fetchAll();


// Closes the database cursor
$statement->closeCursor();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>joshua rogers's kung fu school</title>
    <link rel="stylesheet" href="main.css">
</head>

<body>
    <!-- Main page container -->
    <main class="container">

        <!-- Page heading -->
        <h1>Joshua Rogers Kung Fu School - Majors</h1>

        <!-- Major list section -->
        <section>
            <h2>Major List</h2>

            <!-- Displays all majors from the database -->
            <table class="major-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach ($majors as $major) : ?>
                        <tr>
                            <td>
                                <?php
                                echo htmlspecialchars($major['majorName']);
                                ?>
                            </td>

                            <td>
                                <!-- Sends the selected major ID
                                     to the delete processing page -->
                                <form action="joshua_rogers_delete_major.php"
                                      method="post">

                                    <input type="hidden"
                                           name="major_id"
                                           value="<?php
                                           echo htmlspecialchars(
                                               $major['majorID']
                                           );
                                           ?>">

                                    <button type="submit">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>

        <!-- Add major section -->
        <section class="add-major-section">
            <h2>Add Major</h2>

            <!-- Sends the new major name to the processing page -->
            <form action="joshua_rogers_add_major.php"
                  method="post">

                <label for="major_name">Major Name:</label>

                <input type="text"
                       name="major_name"
                       id="major_name">

                <button type="submit">Add</button>
            </form>
        </section>

        <!-- Returns the user to the student list -->
        <div class="action-links">
            <p>
                <a href="index.php">List Students</a>
            </p>
        </div>

        <!-- Page footer -->
        <footer>
            &copy; <?php echo date("Y"); ?>
            Joshua Rogers Kung Fu School
        </footer>
    </main>
</body>
</html>