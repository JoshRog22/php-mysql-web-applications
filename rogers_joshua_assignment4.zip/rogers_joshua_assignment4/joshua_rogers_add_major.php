<?php
/*
Author: Joshua Rogers
Course: CSCI 4000-W01
Date: 07/11/2026
Assignment 4 - Question 5 Extra Credit
File: joshua_rogers_add_major.php

Purpose:
This page receives a major name from the major list page,
validates the input, inserts the new major into the database,
and returns to the updated major list.
*/


// Connects to the Assignment 4 database using PDO
require_once('joshua_rogers_database.php');


// Receives the major name from the add major form
$major_name = filter_input(INPUT_POST, 'major_name');


// Removes extra spaces from the beginning and end
$major_name = trim((string) $major_name);


// Checks whether the major name textbox was left empty
if ($major_name === '') {

    // Stores the message displayed by the shared error page
    $error = 'Invalid (empty) major data. Check all fields and try again.';

    // Displays the error page created in Question 4
    include('joshua_rogers_error.php');

    // Stops the INSERT query from running
    exit();
}


// Inserts the new major into the major table
$query = 'INSERT INTO major (majorName)
          VALUES (:major_name)';


// Prepares the INSERT query
$statement = $db->prepare($query);


// Binds the submitted major name to the placeholder
$statement->bindValue(':major_name', $major_name);


// Executes the INSERT query
$statement->execute();


// Closes the database cursor
$statement->closeCursor();


// Returns the user to the updated major list
header('Location: joshua_rogers_major_list.php');
exit();
?>