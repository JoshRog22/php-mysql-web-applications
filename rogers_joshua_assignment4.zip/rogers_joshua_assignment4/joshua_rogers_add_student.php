<?php
/*
Author: Joshua Rogers
Course: CSCI 4000-W01
Date: 07/11/2026
Assignment 4 - Question 4
File: joshua_rogers_add_student.php

Purpose:
This page receives new student information from the add
student form, validates the information, inserts the student
into the database using PDO, and returns to the student list.
*/


// Connects to the Assignment 4 database using PDO
require_once('joshua_rogers_database.php');


// Receives and validates the selected major ID
$major_id = filter_input(
    INPUT_POST,
    'major_id',
    FILTER_VALIDATE_INT
);


// Receives the student's first and last names
$first_name = filter_input(INPUT_POST, 'first_name');
$last_name = filter_input(INPUT_POST, 'last_name');


// Receives the student's selected gender
$gender = filter_input(INPUT_POST, 'gender');


// Removes spaces from the beginning and end of the names
$first_name = trim((string) $first_name);
$last_name = trim((string) $last_name);


// Checks for missing or invalid student information
if (
    $major_id === null ||
    $major_id === false ||
    $first_name === '' ||
    $last_name === '' ||
    ($gender !== 'M' && $gender !== 'F')
) {
    // Stores the message displayed by the error page
    $error = 'Invalid (missing) name. Check all fields and try again.';

    // Displays the student input error page
    include('joshua_rogers_error.php');

    // Stops the INSERT query from running
    exit();
}


// Inserts the new student into the student table
$query = 'INSERT INTO student
              (majorID, firstName, lastName, gender)
          VALUES
              (:major_id, :first_name, :last_name, :gender)';


// Prepares the INSERT query
$statement = $db->prepare($query);


// Binds the submitted values to the query placeholders
$statement->bindValue(':major_id', $major_id);
$statement->bindValue(':first_name', $first_name);
$statement->bindValue(':last_name', $last_name);
$statement->bindValue(':gender', $gender);


// Executes the INSERT query
$statement->execute();


// Closes the database cursor
$statement->closeCursor();


// Returns to index.php and displays the student's selected major
header('Location: index.php?major_id=' . $major_id);
exit();
?>