<?php
/*
Author: Joshua Rogers
Course: CSCI 4000-W01
Date: 07/11/2026
Assignment 4 - Question 3
File: joshua_rogers_delete_student.php

Purpose:
This page receives a selected student ID from index.php,
uses PDO to delete that student from the student table,
and then returns the user to the updated student list.
*/


// Connects to the Assignment 4 database using PDO
require_once('joshua_rogers_database.php');


// Receives and validates the selected student ID
$student_id = filter_input(
    INPUT_POST,
    'student_id',
    FILTER_VALIDATE_INT
);


// Receives and validates the currently selected major ID
$major_id = filter_input(
    INPUT_POST,
    'major_id',
    FILTER_VALIDATE_INT
);


// Deletes the student only when a valid student ID was received
if ($student_id !== null && $student_id !== false) {

    // Deletes the selected student record from the student table
    $query = 'DELETE FROM student
              WHERE studentID = :student_id';

    // Prepares the DELETE statement
    $statement = $db->prepare($query);

    // Binds the selected student ID to the named placeholder
    $statement->bindValue(':student_id', $student_id);

    // Executes the DELETE query
    $statement->execute();

    // Closes the database cursor
    $statement->closeCursor();
}


// Uses the first major if no valid major ID was received
if ($major_id === null || $major_id === false) {
    $major_id = 1;
}


// Returns the user to index.php and displays the same major
//returns the browser to the proper page and avoids accidentally deleting the student again if the user refreshes.
header('Location: index.php?major_id=' . $major_id);
exit();
?>