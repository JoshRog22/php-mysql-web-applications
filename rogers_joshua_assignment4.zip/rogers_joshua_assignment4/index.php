<?php
/*
Author: Joshua Rogers
Course: CSCI 4000-W01
Date: 07/11/2026
Assignment 4 - Question 2
File: index.php

Purpose:
This page displays all majors in a navigation area and lists
the students enrolled in the selected major. The user can click
a major name to display the students assigned to that major.
*/


// Connects to the Assignment 4 database using PDO
require_once('joshua_rogers_database.php');


/*
Gets the selected major ID from the URL.

Example:
index.php?major_id=2
*/
$major_id = filter_input(
    INPUT_GET,
    'major_id',
    FILTER_VALIDATE_INT
);


// Uses the first major when no valid major ID is provided
if ($major_id === null || $major_id === false) {
    $major_id = 1;
}


/*
Selects the currently chosen major.

The named placeholder prevents the major ID from being inserted
directly into the SQL statement.
*/
$query = 'SELECT majorID, majorName
          FROM major
          WHERE majorID = :major_id';

$statement = $db->prepare($query);
$statement->bindValue(':major_id', $major_id);
$statement->execute();


// Stores the selected major record
$selected_major = $statement->fetch();


// Closes the database cursor
$statement->closeCursor();


/*
If the URL contains a major ID that does not exist,
the page returns to the first major.
*/
if ($selected_major === false) {
    $major_id = 1;

    $query = 'SELECT majorID, majorName
              FROM major
              WHERE majorID = :major_id';

    $statement = $db->prepare($query);
    $statement->bindValue(':major_id', $major_id);
    $statement->execute();

    $selected_major = $statement->fetch();

    $statement->closeCursor();
}


// Stores the selected major name for the page heading
$major_name = $selected_major['majorName'];


/*
Selects all majors for the navigation area.

The records are arranged by majorID so they appear in the same
order as the records in the database.
*/
$query = 'SELECT majorID, majorName
          FROM major
          ORDER BY majorID';

$statement = $db->prepare($query);
$statement->execute();


// Stores all major records in an array
$majors = $statement->fetchAll();


// Closes the database cursor
$statement->closeCursor();


/*
Selects the students assigned to the chosen major.

Only students whose majorID matches the selected major are
returned by the query.
*/
$query = 'SELECT studentID, firstName, lastName, gender
          FROM student
          WHERE majorID = :major_id
          ORDER BY studentID';

$statement = $db->prepare($query);
$statement->bindValue(':major_id', $major_id);
$statement->execute();


// Stores the students for the selected major
$students = $statement->fetchAll();


// Closes the database cursor
$statement->closeCursor();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>joshua rogers's kung fu school</title>
    <link rel="stylesheet" href="main.css">
</head>

<body>
    <!-- Main page container -->
    <main class="container">

        <!-- Main page heading -->
        <h1>Joshua Rogers Kung Fu School - Students</h1>

        <!-- Student list heading -->
        <h2>Student List</h2>

        <!-- Holds the major navigation and student table -->
        <div class="content">

            <!-- Major navigation area -->
            <aside>
                <h3>Majors</h3>

                <nav aria-label="Major navigation">
                    <ul>
                        <!-- Displays a link for every major -->
                        <?php foreach ($majors as $major) : ?>
                            <li>
                                <a href="?major_id=<?php
                                    echo htmlspecialchars($major['majorID']);
                                ?>">
                                    <?php
                                    echo htmlspecialchars(
                                        $major['majorName']
                                    );
                                    ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </nav>
            </aside>

            <!-- Students belonging to the selected major -->
            <section class="student-section">
                <h3><?php echo htmlspecialchars($major_name); ?></h3>

                <!-- Student information table -->
                <table>
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Gender</th>
							<th>Action</th>
                        </tr>
                    </thead>


                    <tbody>
						<!-- Displays every student in the selected major -->
						<?php foreach ($students as $student) : ?>
							<tr>
								<td>
									<?php echo htmlspecialchars($student['studentID']); ?>
								</td>

								<td>
									<?php echo htmlspecialchars($student['firstName']); ?>
								</td>

								<td>
									<?php echo htmlspecialchars($student['lastName']); ?>
								</td>

								<td>
									<?php echo htmlspecialchars($student['gender']); ?>
								</td>

								<td>
									<!-- Sends the selected student ID and major ID
										 to the delete processing page -->
									<form action="joshua_rogers_delete_student.php"
										  method="post">

										<input type="hidden"
											   name="student_id"
											   value="<?php
											   echo htmlspecialchars($student['studentID']);
											   ?>">

										<input type="hidden"
											   name="major_id"
											   value="<?php
											   echo htmlspecialchars($major_id);
											   ?>">

										<button type="submit">Delete</button>
									</form>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
                </table>
				
				<!-- Links to other student and major actions -->
				<div class="action-links">
					<p>
						<a href="joshua_rogers_add_student_form.php">
							Add Student
						</a>
					</p>

					<p>
						<a href="joshua_rogers_major_list.php">
							List / Add Major
						</a>
					</p>
				</div>

                <!-- Appears if the selected major has no students -->
                <?php if (count($students) === 0) : ?>
                    <p>No students are currently assigned to this major.</p>
                <?php endif; ?>
            </section>
        </div>

        <!-- Page footer -->
        <footer>
            &copy; <?php echo date("Y"); ?>
            Joshua Rogers Kung Fu School
        </footer>
    </main>
</body>
</html>