<?php
/*
Author: Joshua Rogers
Course: CSCI 4000-W01
Date: 07/11/2026
Assignment 4 - Question 5 Extra Credit
File: joshua_rogers_delete_major.php

Purpose:
This page receives a selected major ID, checks whether students
are linked to that major, deletes the major when it is not in use,
and returns to the updated major list.
*/


// Connects to the Assignment 4 database using PDO
require_once('joshua_rogers_database.php');


// Receives and validates the selected major ID
$major_id = filter_input(
    INPUT_POST,
    'major_id',
    FILTER_VALIDATE_INT
);


// Continues only when a valid major ID was received
if ($major_id !== null && $major_id !== false) {

    /*
    Counts the students assigned to the selected major.

    A major with linked students cannot be deleted because
    student.majorID is a foreign key referencing major.majorID.
    */
    $query = 'SELECT COUNT(*) AS studentCount
              FROM student
              WHERE majorID = :major_id';

    $statement = $db->prepare($query);
    $statement->bindValue(':major_id', $major_id);
    $statement->execute();

    $result = $statement->fetch();
    $student_count = $result['studentCount'];

    $statement->closeCursor();


    // Deletes the major only when no students are linked to it
    if ($student_count == 0) {

        $query = 'DELETE FROM major
                  WHERE majorID = :major_id';

        $statement = $db->prepare($query);
        $statement->bindValue(':major_id', $major_id);
        $statement->execute();

        $statement->closeCursor();

        // Returns to the updated major list
        header('Location: joshua_rogers_major_list.php');
        exit();

    } else {

        /*
        Displays a popup message when the major cannot be deleted
        because one or more students are assigned to it.
        */
        echo "<script>
                alert('This major cannot be deleted because students are assigned to it.');
                window.location.href='joshua_rogers_major_list.php';
              </script>";

        exit();
    }

} else {

    // Returns to the major list if an invalid major ID was received
    header('Location: joshua_rogers_major_list.php');
    exit();
}
?>