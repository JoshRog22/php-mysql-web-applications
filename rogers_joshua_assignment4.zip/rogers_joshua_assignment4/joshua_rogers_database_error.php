<?php
/*
Author: Joshua Rogers
Course: CSCI 4000-W01
Date: 07/11/2026
Assignment 4 - Question 2
File: joshua_rogers_database_error.php

Purpose:
This page displays an error message when PHP cannot connect
to the MySQL database.
*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>joshua rogers's kung fu school</title>
    <link rel="stylesheet" href="main.css">
</head>

<body>
    <!-- Main page container -->
    <main class="container">

        <!-- Page heading -->
        <h1>Joshua Rogers Kung Fu School</h1>

        <!-- Database error information -->
        <section class="error-message">
            <h2>Database Error</h2>

            <p>There was an error connecting to the database.</p>

            <p>
                <strong>Error message:</strong>
                <?php echo htmlspecialchars($error_message); ?>
            </p>
        </section>

        <!-- Page footer -->
        <footer>
            &copy; <?php echo date("Y"); ?>
            Joshua Rogers Kung Fu School
        </footer>
    </main>
</body>
</html>