<?php
/*
Author: Joshua Rogers
Course: CSCI 4000-W01
Date: 07/11/2026
Assignment 4 - Question 4
File: joshua_rogers_add_student_form.php

Purpose:
This page retrieves all majors from the major table and
displays a form that allows the user to add a new student.
*/


// Connects to the Assignment 4 database using PDO
require_once('joshua_rogers_database.php');


// Selects all majors for the major dropdown list
$query = 'SELECT majorID, majorName
          FROM major
          ORDER BY majorID';


// Prepares and executes the SELECT query
$statement = $db->prepare($query);
$statement->execute();


// Stores all major records in the $majors array
$majors = $statement->fetchAll();


// Closes the database cursor
$statement->closeCursor();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>joshua rogers's kung fu school</title>
    <link rel="stylesheet" href="main.css">
</head>

<body>
    <!-- Main page container -->
    <main class="container">

        <!-- Page heading -->
        <h1>Joshua Rogers Kung Fu School - Add Student</h1>

        <!-- Add student form section -->
        <section>
            <h2>Add Student</h2>

            <!-- Sends the new student information to the processing page -->
            <form action="joshua_rogers_add_student.php"
                  method="post">

                <!-- Major dropdown list -->
                <label for="major_id">Major:</label>

                <select name="major_id" id="major_id">
                    <?php foreach ($majors as $major) : ?>
                        <option value="<?php
                            echo htmlspecialchars($major['majorID']);
                        ?>">
                            <?php
                            echo htmlspecialchars($major['majorName']);
                            ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <!-- Student first name -->
                <label for="first_name">First Name:</label>

                <input type="text"
                       name="first_name"
                       id="first_name">

                <!-- Student last name -->
                <label for="last_name">Last Name:</label>

                <input type="text"
                       name="last_name"
                       id="last_name">

                <!-- Student gender dropdown list -->
                <label for="gender">Gender:</label>

                <select name="gender" id="gender">
                    <option value="M">Male</option>
                    <option value="F">Female</option>
                </select>

                <!-- Submits the student information -->
                <button type="submit">Add Student</button>
            </form>

            <!-- Returns the user to the student list -->
            <div class="action-links">
                <p>
                    <a href="index.php">View All Students</a>
                </p>
            </div>
        </section>

        <!-- Page footer -->
        <footer>
            &copy; <?php echo date("Y"); ?>
            Joshua Rogers Kung Fu School
        </footer>
    </main>
</body>
</html>