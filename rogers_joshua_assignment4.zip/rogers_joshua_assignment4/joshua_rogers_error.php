<?php
/*
Author: Joshua Rogers
Course: CSCI 4000-W01
Date: 07/11/2026
Assignment 4 - Question 4
File: joshua_rogers_error.php

Purpose:
This page displays an error message when required student
information is missing or invalid.
*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>joshua rogers's kung fu school</title>
    <link rel="stylesheet" href="main.css">
</head>

<body>
    <!-- Main page container -->
    <main class="container">

        <!-- Page heading -->
        <h1>Joshua Rogers Kung Fu School</h1>

        <!-- Student input error information -->
        <section class="error-message">
            <h2>Error</h2>

            <p>
                <?php echo htmlspecialchars($error); ?>
            </p>
        </section>

        <!-- Returns the user to the student list -->
        <div class="action-links">
            <p>
                <a href="index.php">View All Students</a>
            </p>
        </div>

        <!-- Page footer -->
        <footer>
            &copy; <?php echo date("Y"); ?>
            Joshua Rogers Kung Fu School
        </footer>
    </main>
</body>
</html>