/*
================================
Author: Joshua Rogers
Course Code: CSCI 4000
Assignment: Assignmet 3 Question 1
Program Date: July 4, 2026
file: Create_db.sql

Purpose:
This SQL script creates the assignment database,
creates the student table, inserts test records,
creates the joshuaweb database user, and assigns
database privileges.
================================
*/

DROP DATABASE IF EXISTS joshua_rogers_assignment_db;

CREATE DATABASE joshua_rogers_assignment_db;

USE joshua_rogers_assignment_db;

CREATE TABLE student (
    studentID INT(11) NOT NULL AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    PRIMARY KEY (studentID)
);

INSERT INTO student (name, email) VALUES
('PO BLACK', 'poblack@gmail.com'),
('SHIFU HOFFMAN', 'shifuhoffman@gmail.com'),
('TIGRESS JOLIE', 'tigressjolie@gmail.com'),
('JENNIFER YUH', 'jenniferyuh@gmail.com'),
('OX STORMING', 'oxstorming@gmail.com'),
('MONKEY CHAN', 'monkeychan@gmail.com'),
('VIPER LIU', 'viperliu@gmail.com'),
('MANTIS ROGEN', 'mantisrogen@gmail.com'),
('CRANE CROSS', 'cranecross@gmail.com'),
('OOGWAY KIM', 'oogway@gmail.com'),
('PING HONG', 'pinghong@gmail.com');

DROP USER IF EXISTS 'joshuaweb'@'localhost';

CREATE USER 'joshuaweb'@'localhost'
IDENTIFIED BY 'joshuachocolate';

GRANT SELECT, INSERT, UPDATE, DELETE
ON joshua_rogers_assignment_db.*
TO 'joshuaweb'@'localhost';

--this tells sql to "Reload all user accounts and permissions into memory immediately."--
FLUSH PRIVILEGES;