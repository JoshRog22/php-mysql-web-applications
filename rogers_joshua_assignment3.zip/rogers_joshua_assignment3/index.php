<?php
/*
Author: Joshua Rogers
Course: CSCI 4000-W01
Date: 07/04/2026
Assignment 3 - Question 2
File: index.php

Purpose:
This page connects to the database and displays all students
from the student table.
*/

// Connects to the database using the external database file
require_once('joshua_rogers_database.php');

// Selects all student records from the student table
$query = 'SELECT studentID, name, email
          FROM student
          ORDER BY studentID';

// Prepares and runs the SELECT query
$statement = $db->prepare($query);
$statement->execute();

// Stores all student records in the $students array
$students = $statement->fetchAll();

// Closes the database cursor
$statement->closeCursor();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Joshua Rogers's Kung Fu School</title>
    <link rel="stylesheet" href="main.css">
</head>
<body>
    <!-- Main page container -->
    <main class="container">
        <!-- Page heading -->
        <h1>Joshua Rogers Kung Fu School - Students</h1>

        <!-- Student list section -->
        <section>
            <h2>Student List</h2>

            <!-- Student table -->
            <table>
                <tr>
                    <th>Student ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>

                <!-- Displays each student record from the database -->
                <?php foreach ($students as $student) : ?>
                <tr>
                    <td><?php echo htmlspecialchars($student['studentID']); ?></td>
                    <td><?php echo htmlspecialchars($student['name']); ?></td>
                    <td><?php echo htmlspecialchars($student['email']); ?></td>
                    <td>
						<!-- Sends the selected student's ID to the delete page -->
						<form action="joshua_rogers_delete_student.php" method="post">
							<input type="hidden" name="student_id"
								value="<?php echo htmlspecialchars($student['studentID']); ?>">
							<button type="submit">Delete</button>
						</form>
					</td>
                </tr>
                <?php endforeach; ?>
            </table>

            <!-- Link to add student -->
            <a href="joshua_rogers_add_student_form.php">Add Student</a>
        </section>
		
		<!-- Footer -->
        <footer>
            &copy; <?php echo date("Y"); ?> Joshua Rogers Kung Fu School
        </footer>
    </main>
</body>
</html>