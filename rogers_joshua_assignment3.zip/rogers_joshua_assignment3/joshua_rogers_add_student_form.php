<?php
/*
Author: Joshua Rogers
Course: CSCI 4000-W01
Date: 07/04/2026
Assignment 3 - Question 4
File: joshua_rogers_add_student_form.php

Purpose:
This page displays a form that allows the user to enter
a new student's name and email address.
*/

// Connects to the database using the external database file
require_once('joshua_rogers_database.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>joshua rogers's kung fu school</title>
    <link rel="stylesheet" href="main.css">
</head>
<body>
    <!-- Main page container -->
    <main class="container">
        <!-- Page heading -->
        <h1>Joshua Rogers Kung Fu School - Add Student</h1>

        <!-- Add student form section -->
        <section>
            <h2>Add Student</h2>

            <!-- Form sends new student data to the add student processing page -->
            <form action="joshua_rogers_add_student.php" method="post">
                
				<label for="name">Name:</label>
                <input type="text" name="name" id="name">

                <label for="email">Email:</label>
                <input type="email" name="email" id="email">

                <button type="submit">Add Student</button>
				
            </form>

            <!-- Link returns the user to the full student list -->
            <a href="index.php">View All Students</a>
			
        </section>

        <!-- Footer -->
        <footer>
            &copy; <?php echo date("Y"); ?> Joshua Rogers Kung Fu School
        </footer>
    </main>
</body>
</html>