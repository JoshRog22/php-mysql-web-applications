<?php
/*
Author: Joshua Rogers
Course: CSCI 4000-W01
Date: 07/04/2026
Assignment 3 - Question 4
File: joshua_rogers_add_student.php

Purpose:
This page receives student data from the add student form,
uses PDO to insert the new student into the database, and
then displays the updated student list.
*/

// Connects to the database using the external database file
require_once('joshua_rogers_database.php');

// Gets and sanitizes the student name and email from the form
$name = filter_input(INPUT_POST, 'name');
$email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);

// Adds the student only if both fields contain valid data
if ($name !== null && $name !== false && $email !== null && $email !== false) {
    // Inserts the new student record into the student table
    $query = 'INSERT INTO student (name, email)
              VALUES (:name, :email)';

    // Prepares the INSERT query
    $statement = $db->prepare($query);

    // Binds the form values to the query placeholders
    $statement->bindValue(':name', $name);
    $statement->bindValue(':email', $email);

    // Executes the INSERT query
    $statement->execute();

    // Closes the database cursor
    $statement->closeCursor();
}

// Shows the updated student list
include('index.php');
?>