<?php
/*
Author: Joshua Rogers
Course: CSCI 4000-W01
Date: 07/04/2026
Assignment 3 - Question 3
File: joshua_rogers_delete_student.php

Purpose:
This page receives a selected student ID, connects to the database
using PDO, deletes the selected student record, and returns the user
to the main student list.
*/

// Connects to the database using the external database file
require_once('joshua_rogers_database.php');

// Receives and validates the student ID sent from index.php
$student_id = filter_input(INPUT_POST, 'student_id', FILTER_VALIDATE_INT);

// Deletes the selected student only if a valid student ID was received
if ($student_id !== null && $student_id !== false) {
    // Deletes one student record from the student table
    $query = 'DELETE FROM student
              WHERE studentID = :student_id';

    // Prepares the DELETE query
    $statement = $db->prepare($query);

    // Binds the selected student ID to the query placeholder
    $statement->bindValue(':student_id', $student_id);

    // Executes the DELETE query
    $statement->execute();

    // Closes the database cursor
    $statement->closeCursor();
}

// Returns the user to the main student list
include('index.php');
?>