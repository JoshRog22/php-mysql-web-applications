<?php
/*
Author: Joshua Rogers
Course: CSCI 4000-W01
Date: 06/20/2026
Assignment 2 - Question 2
File: index_process.php
*/

// Capture the button value sent from the form using GET.
$sequence = filter_input(INPUT_GET, 'sequence', FILTER_VALIDATE_INT);

// Create an error message if the user reaches this page without choosing a valid button.
$error_message = '';

/*
Input validation for robustness.
Prevents the program from processing invalid sequence values
if the user manually edits the URL or accesses this page directly.
*/
if ($sequence === false || $sequence === null || $sequence < 1 || $sequence > 4) {
    $error_message = 'Please choose one of the four sequence buttons.';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Joshua Rogers's Kung Fu Panda Po Sequence</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="style.css">
</head>

<body>
<main class="container">

    <header>
        <h1>Joshua Rogers's Kung Fu Panda Po Sequence</h1>
    </header>

    <section>

        <?php if ($error_message !== '') : ?>

            <p class="error"><?php echo $error_message; ?></p>

        <?php else : ?>

            <h2>You pressed button <?php echo $sequence; ?>.</h2>

            <h3>Po's Sequence:</h3>

            <div class="sequence-output">

                <?php
                // Button 1: sequence for 10 - 2n.
                if ($sequence === 1) {
                    for ($n = 1; $n <= 9; $n++) {
                        $two_n = 2 * $n;
                        $answer = 10 - $two_n;

                        echo '<p>When n=' . $n . '; ';
                        echo '10-2n = 10-2x' . $n . ' = 10-' . $two_n . ' = ' . $answer . '</p>';
                    }
                }

                // Button 2: sequence for 4n + 3.
                elseif ($sequence === 2) {
                    for ($n = 1; $n <= 9; $n++) {
                        $four_n = 4 * $n;
                        $answer = $four_n + 3;

                        echo '<p>When n=' . $n . '; ';
                        echo '4n+3 = 4x' . $n . '+3 = ' . $four_n . '+3 = ' . $answer . '</p>';
                    }
                }

                // Button 3: sequence for n^2 - 2.
                elseif ($sequence === 3) {
                    for ($n = 1; $n <= 9; $n++) {
                        $n_squared = $n * $n;
                        $answer = $n_squared - 2;

                        echo '<p>When n=' . $n . '; ';
                        echo 'n*n-2 = ' . $n . 'x' . $n . '-2 = ' . $n_squared . '-2 = ' . $answer . '</p>';
                    }
                }

                // Button 4: modified geometric sequence starting with a=3 and r=2.
                else {
                    $value = 3;

                    for ($n = 1; $n <= 9; $n++) {
                        $answer = $value * 2;

                        echo '<p>When n=' . $n . '; ';
                        echo $value . 'x2 = ' . $answer . '</p>';

                        $value = $answer;
                    }
                }
                ?>

            </div>
		<!--ending the 'if' loop for the php-->
        <?php endif; ?>

        <p><a href="index.htm">back to first page</a></p>

    </section>

</main>
</body>
</html>