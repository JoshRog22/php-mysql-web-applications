<?php
/*
Author: Joshua Rogers
Course: CSCI 4000-W01
Date: 06/20/2026
Assignment 2 - Question 4
File: index_process.php
*/

// Capture the secret word from the form using GET.
// FILTER_UNSAFE_RAW allows symbols such as @ and other keyboard characters.
$secret_word = filter_input(INPUT_GET, 'secret_word', FILTER_UNSAFE_RAW);

// Make sure the variable is always a string before using string functions.
if ($secret_word === null) {
    $secret_word = '';
}

// Count the number of characters in the secret word.
$word_length = strlen($secret_word);

// Check whether the secret word contains at least one @ sign.
$contains_at_sign = strpos($secret_word, '@') !== false;

// Determine which validation rules passed.
$has_correct_length = $word_length === 9;
$can_open_scroll = $has_correct_length && $contains_at_sign;

// Escape the user's input before displaying it on the page.
$safe_secret_word = htmlspecialchars($secret_word, ENT_QUOTES, 'UTF-8');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Joshua Rogers's Kung Fu Panda Po Secret Scroll</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="style.css">
</head>

<body>
<main class="container">

    <h1>Joshua Rogers's Kung Fu Panda Po Secret Scroll</h1>

    <section class="results">

        <h2>Po's Guess:</h2>

        <h2>You entered <?php echo $safe_secret_word; ?></h2>

        <?php if ($can_open_scroll) : ?>

            <p>
                "<?php echo $safe_secret_word; ?>" contains exactly 9 characters and there is at least one @ sign.<br>
                Good job! You can open the secret scroll.
            </p>

        <?php else : ?>

            <?php if (!$has_correct_length) : ?>
                <p>"<?php echo $safe_secret_word; ?>" does not contain exactly 9 characters.</p>
            <?php endif; ?>

            <?php if (!$contains_at_sign) : ?>
                <p>"<?php echo $safe_secret_word; ?>" does not contain any @ sign.</p>
            <?php endif; ?>

            <p>You cannot open the secret scroll. Please try again.</p>

        <?php endif; ?>

        <p><a href="index.htm">back to first page</a></p>

    </section>

</main>
</body>
</html>