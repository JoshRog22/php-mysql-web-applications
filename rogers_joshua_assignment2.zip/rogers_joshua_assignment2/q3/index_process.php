<?php
/*
Author: Joshua Rogers
Course: CSCI 4000-W01
Date: 06/20/2026
Assignment 2 - Question 3
File: index_process.php
*/

// Capture and validate row and column values from the form.
$row = filter_input(INPUT_POST, 'row', FILTER_VALIDATE_INT);
$column = filter_input(INPUT_POST, 'column', FILTER_VALIDATE_INT);

// Store error messages for invalid input.
$error_message = '';

if ($row === false || $row === null || $row < 1) {
    $error_message .= 'Po&apos;s row must be a whole number greater than 0.<br>';
}

if ($column === false || $column === null || $column < 1) {
    $error_message .= 'Po&apos;s column must be a whole number greater than 0.<br>';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Joshua Rogers's Kung Fu Panda Po Magic Rectangle</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="style.css">
</head>

<body>
<main class="container">

    <h1>Joshua Rogers's Kung Fu Panda Po Magic Rectangle</h1>

    <section class="results">

        <?php if ($error_message !== '') : ?>

            <p class="error"><?php echo $error_message; ?></p>

        <?php else : ?>

            <h2>Po's Magic Rectangle:</h2>

            <h2>Po's magic rectangle has <?php echo $row; ?> rows, and <?php echo $column; ?> columns.</h2>

            <h3>Nested while loop rectangle</h3>

            <div class="rectangle-output">
                <?php
                // First rectangle generated with nested while loops.
                $current_row = 1;

                while ($current_row <= $row) {
                    $current_column = 1;

                    while ($current_column <= $column) {
                        echo '(XY)';
                        $current_column++;
                    }

                    echo '<br>';
                    $current_row++;
                }
                ?>
            </div>

            <h3>Nested do...while loop rectangle</h3>

            <div class="rectangle-output">
                <?php
                // Second rectangle generated with nested do...while loops.
                $current_row = 1;

                do {
                    $current_column = 1;

                    do {
                        echo 'loc(r' . $current_row . ',c' . $current_column . '); ';
                        $current_column++;
                    } while ($current_column <= $column);

                    echo '<br>';
                    $current_row++;
                } while ($current_row <= $row);
                ?>
            </div>

            <h3>Nested for loop rectangle</h3>

            <div class="rectangle-output">
                <?php
                // Third rectangle generated with nested for loops.
                for ($current_row = 1; $current_row <= $row; $current_row++) {
                    for ($current_column = 1; $current_column <= $column; $current_column++) {
                        $sum = $current_row + $current_column;

                        echo $current_row . '+' . $current_column . '=' . $sum . '; ';
                    }

                    echo '<br>';
                }
                ?>
            </div>

        <?php endif; ?>

        <p><a href="index.htm">back to first page</a></p>

    </section>

</main>
</body>
</html>