<?php
/*
Author: Joshua Rogers
Course: CSCI 4000-W01
Date: 06/20/2026
Assignment 2 - Question 1
File: index_process.php
*/

// Capture and validate form input from index.htm.
$hourly_rate = filter_input(INPUT_POST, 'hourly_rate', FILTER_VALIDATE_FLOAT);
$hours_worked = filter_input(INPUT_POST, 'hours_worked', FILTER_VALIDATE_FLOAT);
$dependents = filter_input(INPUT_POST, 'dependents', FILTER_VALIDATE_INT);

// Create an error message if the user enters invalid data.
$error_message = '';

if ($hourly_rate === false || $hourly_rate === null || $hourly_rate < 0) {
    $error_message .= 'Hourly rate must be a numeric value of 0 or greater.<br>';
}

if ($hours_worked === false || $hours_worked === null || $hours_worked < 0) {
    $error_message .= 'Hours worked must be a numeric value of 0 or greater.<br>';
}

if ($dependents === false || $dependents === null || $dependents < 0) {
    $error_message .= 'Dependents must be a whole number of 0 or greater.<br>';
}

// Only calculate if there are no errors.
if ($error_message === '') {

    // Determine regular and overtime hours.
    if ($hours_worked > 45) {
        $regular_hours = 45;
        $overtime_hours = $hours_worked - 45;
    } else {
        $regular_hours = $hours_worked;
        $overtime_hours = 0;
    }

    // Calculate regular pay, overtime pay, and gross pay.
    $regular_pay = $hourly_rate * $regular_hours;
    $overtime_pay = $hourly_rate * $overtime_hours * 1.5;
    $gross_pay = $regular_pay + $overtime_pay;

    // Determine tax rate based on number of dependents.
    if ($dependents == 0) {
        $tax_rate = 0.25;
    } elseif ($dependents >= 1 && $dependents <= 3) {
        $tax_rate = 0.20;
    } elseif ($dependents >= 4 && $dependents <= 6) {
        $tax_rate = 0.10;
    } else {
        $tax_rate = 0.05;
    }

    // Calculate tax deduction and net pay.
    $tax_deduction = $gross_pay * $tax_rate;
    $net_pay = $gross_pay - $tax_deduction;

    // Format percentage for display.
    $tax_percent = $tax_rate * 100;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Joshua Rogers's Employee Net Pay</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="style.css">
</head>

<body>
<main class="container">

    <header>
        <h1>Joshua Rogers's Employee Net Pay</h1>
    </header>

    <section>
        <p>This page calculates an employee's net pay.</p>

        <?php if ($error_message !== '') : ?>

            <h2>Error:</h2>
            <p class="error"><?php echo $error_message; ?></p>
            <p><a href="index.htm">back to first page</a></p>

        <?php else : ?>

            <h2>Your entered:</h2>

            <table>
                <tr>
                    <td>Employee's hourly rate of pay =</td>
                    <td><strong>$<?php echo number_format($hourly_rate, 0); ?></strong> per hour</td>
                </tr>

                <tr>
                    <td>Number of hours worked that week =</td>
                    <td><strong><?php echo number_format($hours_worked, 0); ?></strong> hours</td>
                </tr>

                <tr>
                    <td>Number of dependents employee has =</td>
                    <td><strong><?php echo $dependents; ?></strong> dependents</td>
                </tr>

                <tr>
                    <td>Number of overtime hours =</td>
                    <td>
                        <strong>
                            <?php echo number_format($hours_worked, 0); ?> - 45 =
                            <?php echo number_format($overtime_hours, 0); ?>
                        </strong>
                        hours
                    </td>
                </tr>

                <tr>
                    <td>First 45 hours pay =</td>
                    <td>
                        <strong>
                            $<?php echo number_format($hourly_rate, 0); ?> x
                            <?php echo number_format($regular_hours, 0); ?> =
                            $<?php echo number_format($regular_pay, 0); ?>
                        </strong>
                    </td>
                </tr>

                <tr>
                    <td>Next <?php echo number_format($overtime_hours, 0); ?> hours pay (overtime) =</td>
                    <td>
                        <strong>
                            $<?php echo number_format($hourly_rate, 0); ?> x
                            <?php echo number_format($overtime_hours, 0); ?> x 1.5 =
                            $<?php echo number_format($overtime_pay, 0); ?>
                        </strong>
                    </td>
                </tr>

                <tr>
                    <td>Gross pay =</td>
                    <td>
                        <strong>
                            $<?php echo number_format($regular_pay, 0); ?> +
                            $<?php echo number_format($overtime_pay, 0); ?> =
                            $<?php echo number_format($gross_pay, 0); ?>
                        </strong>
                    </td>
                </tr>

                <tr>
                    <td>Tax rate for <?php echo $dependents; ?> dependents =</td>
                    <td><strong><?php echo number_format($tax_percent, 0); ?>%</strong></td>
                </tr>

                <tr>
                    <td>Tax deduction =</td>
                    <td>
                        <strong>
                            <?php echo number_format($gross_pay, 0); ?> x
                            <?php echo number_format($tax_percent, 0); ?>% =
                            $<?php echo number_format($tax_deduction, 0); ?>
                        </strong>
                    </td>
                </tr>

                <tr>
                    <td>Net pay =</td>
                    <td>
                        <strong>
                            $<?php echo number_format($gross_pay, 0); ?> -
                            $<?php echo number_format($tax_deduction, 0); ?> =
                            $<?php echo number_format($net_pay, 0); ?>
                        </strong>
                    </td>
                </tr>

                <tr>
                    <td>This employee earned:</td>
                    <td><strong>$<?php echo number_format($net_pay, 0); ?></strong> this week.</td>
                </tr>
            </table>

            <p><a href="index.htm">back to first page</a></p>

        <?php endif; ?>

    </section>

</main>
</body>
</html>