<?php
/*
Author: Joshua Rogers
Course: CSCI 4000
Date: 06/11/2026
Description: Processes Po's power level and displays the matching power metric.
*/

/*Retireve Po's power level entered by the user*/
$power_level = filter_input(INPUT_POST, 'power_level', FILTER_VALIDATE_INT);

/*determines po's power achievement based on power level*/
if ($power_level < 0) {
    $message = "Po eats too much noodle.";
} elseif ($power_level <= 200) {
    $message = "Po reaches the training hall.";
} elseif ($power_level <= 400) {
    $message = "Po reaches the student barracks.";
} elseif ($power_level <= 600) {
    $message = "Po reaches the Peach Tree of Heavenly Wisdom.";
} elseif ($power_level <= 800) {
    $message = "Po climbs the Wu Da Mountains.";
} elseif ($power_level <= 1000) {
    $message = "Po trains at the Pool of Sacred Tears.";
} else {
    $message = "Po defeats Tai Lung.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Joshua Rogers&#39;s Kung Fu Panda Po Power Level</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<!-- Main page container -->
<div class="container">

    <!-- Page heading -->
    <h1>Joshua Rogers&#39;s Kung Fu Panda Po Power Level</h1>

    <!-- Description of page purpose -->
    <p>This page will prompt Joshua Rogers for Kung Fu Panda Po&#39;s power level.</p>

    <!-- Power level conversion rules -->
    <ul>
        <li>Less than 0: Po eats too much noodle</li>
        <li>0 to 200: Po reaches the training hall</li>
        <li>201 to 400: Po reaches the student barracks</li>
        <li>401 to 600: Po reaches the Peach Tree of Heavenly Wisdom</li>
        <li>601 to 800: Po climbs the Wu Da Mountains</li>
        <li>801 to 1000: Po trains at the Pool of Sacred Tears</li>
        <li>Greater than 1000: Po defeats Tai Lung</li>
    </ul>

    <!-- Display power level and corresponding achievement -->
    <div class="results">
        <p><strong>Po&#39;s power level is <?php echo htmlspecialchars($power_level); ?>.</strong></p>
        <p><strong><?php echo htmlspecialchars($message); ?></strong></p>
    </div>

    <!-- Return to original input page -->
    <a href="index.htm">Back to first page</a>

</div>

</body>
</html>