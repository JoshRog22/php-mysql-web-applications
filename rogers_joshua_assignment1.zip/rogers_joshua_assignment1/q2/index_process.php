<?php
/*
Author: Joshua Rogers
Course: CSCI 4000-W01
Date: 06/11/2026
Description: Processes customer age and calculates dance ticket price.
*/

/*retrieves customer age entered from the form*/
$age = filter_input(INPUT_POST, 'age', FILTER_VALIDATE_INT);

/*determines ticket price based on customer age*/
if ($age < 4) {
    $ticket_price = 3;
} elseif ($age <= 16) {
    $ticket_price = 7;
} else {
    $ticket_price = 9;
}

/*format ticket price for currecy display*/
$ticket_price_f = number_format($ticket_price, 2);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Joshua Rogers's Dance Ticket Price</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<!-- Main content container -->
<div class="container">

    <!-- Page heading -->
    <h1>Joshua Rogers's Dance Ticket Price</h1>

    <!-- Description of page purpose -->
    <p>This page will decide the cost of Joshua's dance ticket price based on the customer's age.</p>

    <!-- Ticket pricing rules -->
    <ul>
        <li>Under age 4, the cost is $3.00</li>
        <li>Between ages 4 and 16, the cost is $7.00</li>
        <li>Older than 16, the cost is $9.00</li>
    </ul>

    <!-- Display customer age and ticket price -->
    <div class="results">
        <p>
            The customer is <?php echo htmlspecialchars($age); ?> years old,
            and the cost of Joshua's ticket is
            $<?php echo htmlspecialchars($ticket_price_f); ?>.
        </p>
    </div>

    <!-- Return to original input page -->
    <a href="index.htm">Back to first page</a>

</div>

</body>
</html>