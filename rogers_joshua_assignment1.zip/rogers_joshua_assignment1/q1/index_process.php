<?php
/*
Author: Joshua Rogers
Course: CSCI 4000-W01
Date: 06/11/2026
Description: PHP Processes movie information submitted from index.htm.
*/

/*retrieves and cleans up user input from the POST form*/
$movie_name = trim(filter_input(INPUT_POST, 'movie_name'));
$director = trim(filter_input(INPUT_POST, 'director'));

$release_year_input = trim(filter_input(INPUT_POST, 'release_year'));
$release_year = filter_var($release_year_input, FILTER_VALIDATE_INT);

$budget_input = trim(filter_input(INPUT_POST, 'budget'));
$box_office_input = trim(filter_input(INPUT_POST, 'box_office'));

/*validates budge and box office values as numeric data*/
$budget = filter_var($budget_input, FILTER_VALIDATE_FLOAT);
$box_office = filter_var($box_office_input, FILTER_VALIDATE_FLOAT);

/* Variable used to store validation error messages */
$error_message = "";

/*ehck for invalid numeric input*/
if ($budget === false) {
    $error_message .= "Budget must be a valid number.<br>";
}

if ($box_office === false) {
    $error_message .= "Box Office must be a valid number.<br>";
}

if ($release_year === false) {
    $error_message .= "Release Year must be a valid number.<br>";
}

/*calculates movie profit when no errors are present*/
if (empty($error_message)) {
    $profit = $box_office - $budget;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Joshua Rogers's Movie Page</title> 
    <link rel="stylesheet" href="style.css">
</head>

<body>

<!-- Main page container -->
<div class="container">

    <!-- Page heading -->
    <h1>Joshua Rogers's Favorite Movie</h1>

    <!-- Display validation errors and redisplay form if invalid data was entered -->
    <?php if (!empty($error_message)) { ?>

        <!-- Error message area -->
        <div class="error">
            <p><?php echo $error_message; ?></p>
        </div>

        <p>Please correct the information below and submit the form again.</p>

        <!-- Form with previously entered values preserved -->
        <form action="index_process.php" method="post">

            <label>Movie Name:</label>
            <input type="text" name="movie_name" value="<?php echo htmlspecialchars($movie_name); ?>" required>

            <label>Director:</label>
            <input type="text" name="director" value="<?php echo htmlspecialchars($director); ?>" required>

            <label>Release Year:</label>
            <input type="text" name="release_year" value="<?php echo htmlspecialchars($release_year_input); ?>" required>

            <label>Budget (US$, million):</label>
            <input type="text" name="budget" value="<?php echo htmlspecialchars($budget_input); ?>" required>

            <label>Box Office (US$, million):</label>
            <input type="text" name="box_office" value="<?php echo htmlspecialchars($box_office_input); ?>" required>

            <!-- Resubmit corrected information -->
            <input type="submit" value="Submit">

        </form>

    <?php } else { ?>

        <!-- Display processed movie information when validation succeeds -->
        <p>This page displays the information about Joshua Rogers's favorite movie.</p>

        <div class="results">

            <!-- Display submitted movie information -->
            <p><strong>Movie Name:</strong> <?php echo htmlspecialchars($movie_name); ?></p>
            <p><strong>Directed by:</strong> <?php echo htmlspecialchars($director); ?></p>
            <p><strong>Release Year:</strong> <?php echo htmlspecialchars($release_year); ?></p>
            <p><strong>Budget US$, million:</strong> $<?php echo htmlspecialchars(number_format($budget, 2)); ?></p>
            <p><strong>Box Office US$, million:</strong> $<?php echo htmlspecialchars(number_format($box_office, 2)); ?></p>

            <!-- Display profit calculation -->
            <p><strong>Profit US$, million:</strong>
                $<?php echo htmlspecialchars(number_format($box_office, 2)); ?> -
                $<?php echo htmlspecialchars(number_format($budget, 2)); ?> =
                $<?php echo htmlspecialchars(number_format($profit, 2)); ?> million
            </p>

        </div>

        <!-- Return to original input page -->
        <a href="index.htm">Back to first page</a>

    <?php } ?>

</div>

</body>
</html>